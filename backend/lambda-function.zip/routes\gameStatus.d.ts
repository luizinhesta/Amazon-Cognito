import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleGameStatus(event: APIGatewayProxyEvent): LambdaResponse;
//# sourceMappingURL=gameStatus.d.ts.map