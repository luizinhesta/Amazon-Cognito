"use strict";
// GET /game/status - Returns game status message
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleGameStatus = handleGameStatus;
const response_1 = require("../utils/response");
function handleGameStatus(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    return (0, response_1.buildResponse)(200, {
        message: 'O jogo será disponibilizado no Projeto 2',
    }, origin);
}
//# sourceMappingURL=gameStatus.js.map