import { APIGatewayProxyEvent } from 'aws-lambda';
import { LambdaResponse } from '../types';
export declare function handleMe(event: APIGatewayProxyEvent): LambdaResponse;
//# sourceMappingURL=me.d.ts.map