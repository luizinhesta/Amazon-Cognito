"use strict";
// GET /me - Returns authenticated user data from Cognito claims
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleMe = handleMe;
const response_1 = require("../utils/response");
function handleMe(event) {
    const origin = event.headers?.origin || event.headers?.Origin;
    const claims = event.requestContext?.authorizer?.claims;
    if (!claims || !claims.sub) {
        return (0, response_1.buildErrorResponse)(401, 'Não foi possível identificar o usuário', origin);
    }
    return (0, response_1.buildResponse)(200, {
        autenticado: true,
        usuarioId: claims.sub,
        email: claims.email || '',
        nome: claims.name || '',
        apelido: claims.preferred_username || '',
    }, origin);
}
//# sourceMappingURL=me.js.map