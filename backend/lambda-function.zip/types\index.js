"use strict";
// Shared types for the backend Lambda function
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=index.js.map