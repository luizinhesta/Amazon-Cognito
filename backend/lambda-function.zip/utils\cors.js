"use strict";
// CORS utility - validates origins and builds CORS headers
Object.defineProperty(exports, "__esModule", { value: true });
exports.isOriginAllowed = isOriginAllowed;
exports.getCorsHeaders = getCorsHeaders;
/**
 * Allowed origins list built at module load time:
 * 1. Always includes http://localhost:5173 (Vite dev server)
 * 2. Additional origins from ALLOWED_ORIGINS env var (comma-separated)
 */
const ALLOWED_ORIGINS = [
    'http://localhost:5173',
    ...(process.env.ALLOWED_ORIGINS ?? '')
        .split(',')
        .map((origin) => origin.trim())
        .filter((origin) => origin.length > 0),
];
/**
 * Checks if the given origin is in the allowed origins list.
 * Returns false for undefined origins.
 */
function isOriginAllowed(origin) {
    if (!origin) {
        return false;
    }
    return ALLOWED_ORIGINS.includes(origin);
}
/**
 * Returns CORS headers if the request origin is allowed.
 * If the origin is not allowed, returns an empty object.
 */
function getCorsHeaders(requestOrigin) {
    if (!isOriginAllowed(requestOrigin)) {
        return {};
    }
    return {
        'Access-Control-Allow-Origin': requestOrigin,
        'Access-Control-Allow-Headers': 'Authorization,Content-Type',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
    };
}
//# sourceMappingURL=cors.js.map