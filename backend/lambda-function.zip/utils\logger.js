"use strict";
// Secure logger - masks sensitive data in log output
Object.defineProperty(exports, "__esModule", { value: true });
exports.maskSensitiveData = maskSensitiveData;
exports.logSafe = logSafe;
exports.logError = logError;
const SENSITIVE_KEYS = ['token', 'password', 'secret', 'authorization'];
/**
 * Masks sensitive data showing at most the last 4 characters.
 * - If value length <= 4: returns all asterisks (same length)
 * - If value length > 4: replaces first (length - 4) characters with asterisks, shows last 4 as-is
 */
function maskSensitiveData(value) {
    if (value.length <= 4) {
        return '*'.repeat(value.length);
    }
    const visiblePart = value.slice(-4);
    const maskedPart = '*'.repeat(value.length - 4);
    return maskedPart + visiblePart;
}
function isSensitiveKey(key) {
    const lowerKey = key.toLowerCase();
    return SENSITIVE_KEYS.some((sensitive) => lowerKey.includes(sensitive));
}
function sanitizeContext(context) {
    const sanitized = {};
    for (const [key, value] of Object.entries(context)) {
        if (typeof value === 'string' && isSensitiveKey(key)) {
            sanitized[key] = maskSensitiveData(value);
        }
        else {
            sanitized[key] = value;
        }
    }
    return sanitized;
}
/**
 * Logs a message to console.log with sanitized context.
 * String values in context whose keys contain 'token', 'password', 'secret', or 'authorization'
 * are masked to show at most the last 4 characters.
 */
function logSafe(message, context) {
    if (context) {
        console.log(message, sanitizeContext(context));
    }
    else {
        console.log(message);
    }
}
/**
 * Logs a message to console.error with sanitized context.
 * Same masking rules as logSafe.
 */
function logError(message, context) {
    if (context) {
        console.error(message, sanitizeContext(context));
    }
    else {
        console.error(message);
    }
}
//# sourceMappingURL=logger.js.map